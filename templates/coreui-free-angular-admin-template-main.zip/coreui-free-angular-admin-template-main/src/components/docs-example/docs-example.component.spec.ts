// import { ComponentFixture, TestBed } from '@angular/core/testing';
//
// import { DocsExampleComponent } from './docs-example.component';
//
// describe('DocsExampleComponent', () => {
//   let component: DocsExampleComponent;
//   let fixture: ComponentFixture<DocsExampleComponent>;
//
//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [ DocsExampleComponent ]
//     })
//     .compileComponents();
//   });
//
//   beforeEach(() => {
//     fixture = TestBed.createComponent(DocsExampleComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });
//
//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
